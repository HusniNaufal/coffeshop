export default function lihatsemua() {
  return (
    <>
      <h1 className="text-4xl font-bold">HAYO MAU NGAPAIN WKWKWK</h1>
    </>
  );
}
